<!doctype html>
<html lang="en">

<head>
    <title>Customers</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS v5.2.1 -->
    <link href="/assets/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="/assets/css/all.min.css">
    <link rel="stylesheet" href="/assets/css/login.css">

</head>

<body>
<?php /**PATH /var/www/html/laravel/AdminUserAuthSystem (singleTableUsers)/resources/views/layouts/header.blade.php ENDPATH**/ ?>