<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('school.dashboard', ['slug' => $auth->slug])); ?>">
                <i class="icon-grid menu-icon"></i>
                <span class="menu-title">Dashboard</span>
            </a>
        </li>
        
        
    </ul>
</nav>
<?php /**PATH /var/www/html/laravel/school/resources/views/school/layouts/sidebar.blade.php ENDPATH**/ ?>