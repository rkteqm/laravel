<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($mailData['title']); ?></title>
</head>

<body>
    <h1><?php echo e($mailData['title']); ?></h1>
    <h2><?php echo e($mailData['body']); ?></h2>
    <h6>Username: <?php echo e($mailData['username']); ?></h6>
    <h6>Password: <?php echo e($mailData['password']); ?></h6>
    <p>Visit your school: <a href="<?php echo e($mailData['link']); ?>">Click here</a></p>
    <p>Thank You.</p>
</body>

</html>
<?php /**PATH /var/www/html/laravel/school/resources/views/email/schoolmail.blade.php ENDPATH**/ ?>