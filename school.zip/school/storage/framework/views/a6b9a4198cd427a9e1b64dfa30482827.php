<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('admin.dashboard')); ?>">
                <i class="icon-grid menu-icon"></i>
                <span class="menu-title">Dashboard</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('admin.addschool')); ?>">
                <i class="icon-head menu-icon"></i>
                <span class="menu-title">Add School</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('admin.school')); ?>">
                <i class="icon-grid menu-icon"></i>
                <span class="menu-title">Schools</span>
            </a>
        </li>
        
        <li class="nav-item">
            <form method="POST" action="<?php echo e(route('admin.logout')); ?>">
                <?php echo csrf_field(); ?>
                <a class="nav-link" href="route('admin.logout')"
                    onclick="event.preventDefault();
                this.closest('form').submit();">
                    <i class="ti-power-off menu-icon"></i>
                    <span class="menu-title">
                        <?php echo e(__('Log Out')); ?>

                    </span>
                </a>
            </form>
        </li>
    </ul>
</nav>
<?php /**PATH /var/www/html/laravel/school/resources/views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>