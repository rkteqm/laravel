<!-- place footer here -->
<footer class="bg-dark text-center text-white">
    <!-- Footer -->
    <!-- Copyright -->
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2);">
        © 2020 Copyright:
        <a class="text-white" href="/">Home</a>
    </div>
    <!-- Copyright -->
</footer>
<!-- Footer -->
<!-- Bootstrap JavaScript Libraries -->
<script src="/assets/js/popper.min.js"></script>

<script src="/assets/js/bootstrap.min.js"></script>
</body>

</html>
<?php /**PATH /var/www/html/laravel/school/resources/views/layouts/footer.blade.php ENDPATH**/ ?>