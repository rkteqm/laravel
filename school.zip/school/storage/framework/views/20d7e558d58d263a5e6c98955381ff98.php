<?php echo $__env->make('user.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('main-section'); ?>

<?php /**PATH /var/www/html/laravel/AdminUserAuthSystem (singleTableUsers)/resources/views/user/layouts/main.blade.php ENDPATH**/ ?>