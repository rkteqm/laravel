<?php $__env->startSection('main-section'); ?>
    <!-- main-panel start -->
    <div class="main-panel">
        <div class="content-wrapper">
            <div class="row">
                <div class="col-12 grid-margin stretch-card">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Add New School</h4>
                            <p class="card-description">
                                Basic School Details
                            </p>
                            <form class="forms-sample" enctype="multipart/form-data" method="post"
                                action="<?php echo e(route('admin.addschool')); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="row">
                                    <div class="form-group col-6">
                                        <label for="exampleInputName1">School Logo</label>
                                        <span class="text-danger far fa-user">
                                            <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </span>
                                        <input type="file" name="logo" accept="image/png" class="form-control" id=""
                                            placeholder="Name">
                                    </div>
                                    <div class="form-group col-6">
                                        <label for="exampleInputName1">School Name</label>
                                        <span class="text-danger far fa-user">
                                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </span>
                                        <input type="text" name="name" value="<?php echo e(old('name')); ?>" class="form-control" id="exampleInputName1"
                                            placeholder="Name">
                                    </div>
                                    <div class="form-group col-6">
                                        <label for="exampleInputEmail3">Email address</label>
                                        <span class="text-danger far fa-user">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </span>
                                        <input type="email" name="email" value="<?php echo e(old('email')); ?>" class="form-control" id="exampleInputEmail3"
                                            placeholder="Email">
                                    </div>
                                    <div class="form-group col-6">
                                        <label for="exampleInputPassword4">Password</label>
                                        <span class="text-danger far fa-user">
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </span>
                                        <input type="password" name="password" value="<?php echo e(old('password')); ?>" class="form-control"
                                            id="exampleInputPassword4" placeholder="Password">
                                    </div>
                                    <div class="form-group col-6">
                                        <label for="exampleSelectGender">Institution Type</label>
                                        <span class="text-danger far fa-user">
                                            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </span>
                                        <select class="form-control" name="type" id="exampleSelectGender">
                                            <option selected disabled>Select</option>
                                            <option value="G" <?php echo e(old('type') == 'G' ? 'selected' : ''); ?>>Government</option>
                                            <option value="P" <?php echo e(old('type') == 'P' ? 'selected' : ''); ?>>Private</option>
                                        </select>
                                    </div>
                                    <div class="form-group col-6">
                                        <label for="exampleInputCity1">City</label>
                                        <span class="text-danger far fa-user">
                                            <?php $__errorArgs = ['city'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </span>
                                        <input type="text" name="city" value="<?php echo e(old('city')); ?>" class="form-control" id="exampleInputCity1"
                                            placeholder="Location">
                                    </div>
                                    <div class="form-group col-12">
                                        <label for="exampleTextarea1">Description</label>
                                        <span class="text-danger far fa-user">
                                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <?php echo e($message); ?>

                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </span>
                                        <textarea class="form-control" name="description" id="exampleTextarea1" rows="4"><?php echo e(old('description')); ?></textarea>
                                    </div>
                                </div>
                                <div class="text-center">
                                    <button type="submit" class="btn btn-primary mr-2">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- main-panel ends -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/school/resources/views/admin/school/addschool.blade.php ENDPATH**/ ?>