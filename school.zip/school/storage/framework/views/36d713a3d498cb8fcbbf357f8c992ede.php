<?php $__env->startSection('main-section'); ?>
    <section class="vh-100 gradient-custom abcd">
        <div class="wrapper">
            <div class="logo">
                <img src="/assets/img/logo.jpg" alt="">
            </div>
            <div class="text-center mt-4 name">
                Staff Login
            </div>
            <form class="p-3 mt-3" method="POST" action="<?php echo e(route('login')); ?>">
                <?php echo csrf_field(); ?>
                <span class="text-danger far fa-user">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </span>
                <div class="form-field d-flex align-items-center">
                    <input class="text-center" type="email" name="email" placeholder="Username"
                        value="<?php echo e(old('email')); ?>">
                </div>
                <span class="text-danger far fa-user">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message); ?>

                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </span>
                <div class="form-field d-flex align-items-center">
                    <input class="text-center" type="password" name="password" placeholder="Password">
                </div>
                <button class="btn mt-3">Login</button>
            </form>
            <div class="text-center fs-6">
                <?php if(Route::has('password.request')): ?>
                <a href="<?php echo e(route('password.request')); ?>">Forget password?</a>
                <?php endif; ?>
                or
                <?php if(Route::has('register')): ?>
                    <a href="<?php echo e(route('register')); ?>">Sign up</a>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/laravel/school/resources/views/auth/login.blade.php ENDPATH**/ ?>