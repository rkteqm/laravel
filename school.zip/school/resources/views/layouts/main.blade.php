@include('layouts.header')
@include('layouts.navbar')
@yield('main-section')
{{-- @include('layouts.footer') --}}
